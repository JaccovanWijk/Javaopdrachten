import java.io.*;

public class BRTest {

  private int calls;
  private int successfulCalls;
  private int totalReturned;
  private int[] excepCounts;

  public void callIt() {
    calls++;

    try {
      int value = BadRandom.randVal();
    } catch (ArithmeticException a) {
      excepCounts[0]++;
      System.err.println("ArithmeticException");
    } catch (NullPointerException n) {
      excepCounts[1]++;
      System.err.println("NullPointerException");
    } catch (ArrayIndexOutOfBoundsException b) {
      excepCounts[2]++;
      System.err.println("ArrayIndexOutOfBoundsException");
    } catch (ClassCastException c) {
      excepCounts[3]++;
      System.err.println("ClassCastException");
    } catch (NegativeArraySizeException d) {
      excepCounts[4]++;
      System.err.println("NegativeArraySizeException");
    }
    successfulCalls++;
    totalReturned++;
  }

  public void resetCounts() {
    calls = 0;
    successfulCalls = 0;
    excepCounts = new int[] {0,0,0,0,0};
  }

  public void nRandInts(int n) {
    for (int i = 0; i < n; i++) {
      callIt();
    }
  }

  public void writeData() {
    System.out.println("It's called " + calls + " times.");
    System.out.println("It's successfully called " + successfulCalls + " times.");
    System.out.println("The total returned values is " + totalReturned);
    System.out.println("The percentage of calls with exception is " + (100 - 100*successfulCalls/calls));
    System.out.println("The percentage of successfull calls is " + (100*successfulCalls/calls));
  }

  public static void main (String[] args) throws IOException {
    BRTest Me = new BRTest();
    Me.resetCounts();
    Me.nRandInts(30);
    Me.writeData();
  }
}
/* Need to import java.io package to use the BufferedReader and
	 InputStreamReader.
*/
import java.io.*;

public class Student {

  private static BufferedReader stdIn = new BufferedReader(new
		InputStreamReader(System.in));

  private String name;
  private int age;

  public Student () {
    name = "";
    age = 0;
  }

  public void readName () throws IOException {
    System.out.print("Input your name: ");
    name = stdIn.readLine();
  }

  public void printName () {
    System.out.println("Name: " + name);
  }


  public void readAge() throws IOException {

    do {
      System.out.print("Input your age: ");
      try {
        age = Integer.parseInt(stdIn.readLine());
      } catch (IOException e) {
        System.err.println("ja kut, IEODXException");
      } catch (NumberFormatException n) {
        System.err.println("ja kut, NumberFormatException");
        age = -1;
      }
    } while (age < 0 || age > 150);
  }

  public void printAge(){
    System.out.println("age: "+ age);
  }

  public static void main (String[] args) throws IOException {
    Student me = new Student();
    me.readName();
    me.readAge();

    me.printName();
    me.printAge();
  }
}







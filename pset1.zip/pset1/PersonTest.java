class Person {

   // Properties of the class...
   private String name;
   public  int    age;
   private int    length;

   // Methods of the class...
   public void talk() {
      System.out.println("Hi, my name's " + name);
      System.out.println("and my age is " + age);
      System.out.println("and my length is " + length);

      commentAboutAge();
   }
   public void commentAboutAge() {
      if (age < 5) {
         System.out.println("baby");
      }
      if (age == 5) {
         System.out.println("time to start school");
      }
      if (age > 60) {
         System.out.println("old person");
      }
   }
   public void growOlder() {
      age++;
   }
   public void giveKnighthood() {
      name = "Sir " + name;
   }
   public void growOlderby() {
      int older = 10;
      age += older;
   }

}

class PersonTest {

   // The main method is the point of entry into the program...
   public static void main(String[] args) {

      Person ls = new Person();
      Person wp = new Person();

      wp.growOlder();

      wp.giveKnighthood();

      ls.growOlderby();

      ls.talk();
      wp.talk();

      int age = ls.age;
      System.out.println("his age is " + age);

   }

}

